# -*- coding: utf-8 -*-
"""
Created on Tue Dec 17 15:56:15 2019

@author: ludovic.venet
"""

import cv2
import numpy as np
import sys

path_Image = sys.argv[1]
path_Output = sys.argv[2]

# Using cv2.imread() method
img = cv2.imread(path_Image,0)

max = np.amax(img)
#min = np.amin(img)


########
small_img = cv2.resize(img,(28,28))

_,newIm = cv2.threshold(small_img,max-100,255,cv2.THRESH_BINARY_INV)

cv2.imwrite(path_Output,newIm)

