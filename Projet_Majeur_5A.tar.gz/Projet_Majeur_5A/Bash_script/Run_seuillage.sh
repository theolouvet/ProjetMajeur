path_csv="../small_training_dataset/small_training_dataset.csv"
PATH_dataset="../small_training_dataset/"
PATH_Output="../small_training_dataset/Output_seuillage/"

mkdir -p $PATH_Output

i=0

while IFS=, read field1 field2 field3
do
	if [[ $i -gt 0 ]];then
		ID=$field3
		PATH_image=$PATH_dataset$ID".jpg"
		PATH_Output_image=$PATH_Output$ID".jpg"
		
		python ../Python_Script/Seuillage.py $PATH_image $PATH_Output_image
	fi
	((i++))
done < $path_csv

