#path_dataset=/tmp/mozilla_ludovic.venet0/ImageCLEF2013PlantTaskTrainPackage-PART-1/train
#path_dataset=/tmp/ImageCLEF2013PlantTaskTrainPackage-PART-2/train
#path_dataset=/tmp/ImageCLEF2013PlantTaskTestAndTaskPackage/TestAndTaskPackage/Data/Test/
path_dataset=/tmp/ImageCLEF2013PlantTaskTestAndTaskPackage/TestAndTaskPackage/Data/GroundTruth/

#path_csv=../csv/train_dataset.csv
#path_csv=../csv/test_dataset.csv
path_csv=../csv/Ground_truth_test_dataset.csv

touch $path_csv
echo "species, white background,ID" >> $path_csv

for file in `ls $path_dataset | grep .xml`
do
	type_background=`cat $path_dataset/$file | grep Type | cut -d '>' -f2 | cut -d '<' -f1`
	specie=`cat $path_dataset/$file | grep ClassId | cut -d '>' -f2 | cut -d '<' -f1`
	leaf=`cat $path_dataset/$file | grep Content | cut -d '>' -f2 | cut -d '<' -f1`
	ID=`echo $file | cut -d . -f1`
	if [[ $leaf = "Leaf" ]];then
		if [[ $type_background = "NaturalBackground" ]];then
			background=0
		fi
		if [[ $type_background = "SheetAsBackground" ]];then
			background=1
		fi
		echo "$specie,$background,$ID" >> $path_csv
	fi
done
