#Input_directory=/tmp/ImageCLEF2013PlantTaskTrainPackage-PART-*
#Output_directory=/tmp/training_dataset/

Input_directory=/tmp/ImageCLEF2013PlantTaskTestAndTaskPackage/TestAndTaskPackage/Data/Test/
Output_directory=/tmp/test_dataset/

while IFS=, read field1 field2 field3
do
	image=`find $Input_directory -name "$field2.jpg"`
	if [[ -z $image ]];then
		echo "Image "$field3" not found"
	else
		mv $image $Output_directory
	fi
done < ~/Bureau/Projet_Majeur_5A/csv/test_dataset.csv
